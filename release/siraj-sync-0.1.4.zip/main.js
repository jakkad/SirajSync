"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => SirajSync
});
module.exports = __toCommonJS(main_exports);
var import_obsidian2 = require("obsidian");

// src/api.ts
var import_obsidian = require("obsidian");

// src/model.ts
var TYPES = {
  book: "Books",
  movie: "Movies",
  tv: "TV shows",
  podcast: "Podcasts",
  youtube: "YouTube",
  article: "Articles",
  tweet: "Tweets"
};
var ID = "sirajhub-id";
var ACCOUNT = "sirajhub-account";
var ULID = /^[0-9A-HJKMNP-TV-Z]{26}$/;
var KEY = /^srj_sync_[a-f0-9]{64}$/;
var STATUSES = {
  suggestions: "Suggestions",
  in_progress: "In progress",
  finished: "Finished",
  archived: "Archived"
};
var statusIds = Object.keys(STATUSES);
var TEXT = ["title", "status", "creator", "description", "coverUrl", "releaseDate", "sourceUrl", "externalId", "notes"];
var NUMBERS = ["durationMins", "pageCount", "rating"];
var READ_ONLY = [
  "contentType",
  "subtitle",
  "progressPercent",
  "progressCurrent",
  "progressTotal",
  "createdAt",
  "updatedAt",
  "startedAt",
  "finishedAt",
  "lastTouchedAt"
];
var COMMON = "title = title\ncreator = creator\nstatus = siraj-status\nrating = siraj-rating\nsourceUrl = source\ncoverUrl = cover\nreleaseDate = release-date\ndescription = description\nnotes = siraj-notes";
var EXTRAS = {
  book: "pageCount = pages\nmetadata.isbn = isbn\nmetadata.genres = genres",
  movie: "durationMins = runtime\nmetadata.genres = genres",
  tv: "metadata.seasonCount = seasons\nmetadata.genres = genres",
  podcast: "metadata.feedUrl = feed\nmetadata.episodeCount = episodes",
  youtube: "durationMins = runtime\nmetadata.channelId = channel-id",
  article: "metadata.siteName = site\nmetadata.wordCount = words\nmetadata.readingTimeMins = reading-minutes",
  tweet: "metadata.authorHandle = author-handle"
};
function defaults() {
  return {
    server: "",
    secret: "",
    interval: 0,
    removeUnmappedProperties: false,
    statuses: [...statusIds],
    types: Object.fromEntries(Object.entries(TYPES).map(([type, label]) => [
      type,
      { folder: `SirajHub/${label}`, properties: `${COMMON}
${EXTRAS[type]}`, body: "" }
    ]))
  };
}
function supportsField(field, type) {
  return (field !== "pageCount" || type === "book") && (TEXT.includes(field) || NUMBERS.includes(field) || READ_ONLY.includes(field) || /^metadata\.[\w-]+(?:\.[\w-]+)*$/.test(field));
}
function parseRules(text, type) {
  const keys = /* @__PURE__ */ new Set();
  const properties2 = /* @__PURE__ */ new Set([ID, ACCOUNT, "__proto__", "constructor", "prototype", "position"]);
  return text.split(/\r?\n/).flatMap((line, index) => {
    if (!line.trim()) return [];
    const match = /^\s*([\w.]+)\s*=\s*([\p{L}\p{N}_][\p{L}\p{M}\p{N}_. -]*)$/u.exec(line.trim());
    if (!match) throw Error(`Line ${index + 1}: use field = property.`);
    const field = match[1];
    const property = match[2];
    const writable = TEXT.includes(field) || NUMBERS.includes(field);
    if (!supportsField(field, type)) {
      throw Error(`Unsupported field: ${field}.`);
    }
    if (keys.has(field) || properties2.has(property.toLowerCase())) {
      throw Error(`Duplicate or reserved mapping: ${field} = ${property}.`);
    }
    keys.add(field);
    properties2.add(property.toLowerCase());
    return [{ field, property, writable }];
  });
}
var bodyStart = "<!-- siraj-sync:body -->";
var bodyEnd = "<!-- /siraj-sync:body -->";
var bodyField = /\{\{([^{}\r\n]+)\}\}/g;
function validateBodyTemplate(template, type) {
  for (const [, token] of template.matchAll(bodyField)) {
    const field = token.trim();
    if (!supportsField(field, type)) throw Error(`Unsupported body field: ${field}.`);
  }
}
function renderBody(template, item) {
  return template.replace(bodyField, (_, token) => {
    const value = valueAt(item, token.trim());
    return Array.isArray(value) ? value.join(", ") : String(value ?? "");
  }).replaceAll(bodyStart, "&lt;" + bodyStart.slice(1)).replaceAll(bodyEnd, "&lt;" + bodyEnd.slice(1)).trim();
}
function updateBody(body, rendered, newline) {
  const start = body.indexOf(bodyStart);
  const end = body.indexOf(bodyEnd);
  const block = rendered ? [bodyStart, rendered.replace(/\r?\n/g, newline), bodyEnd].join(newline) : "";
  if (start === -1 && end === -1) {
    if (!block) return body;
    return body + (body ? newline + newline : "") + block;
  }
  if (start === -1 || end < start || body.indexOf(bodyStart, start + 1) !== -1 || body.indexOf(bodyEnd, end + 1) !== -1) {
    throw Error("The Siraj Sync body markers are incomplete or duplicated. Check the note before syncing.");
  }
  const separator = newline + newline;
  const before = body.slice(0, start);
  const after = body.slice(end + bodyEnd.length);
  if (block) return before + block + after;
  return (before.endsWith(separator) ? before.slice(0, -separator.length) : before) + after;
}
function serverOrigin(value) {
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    throw Error("Enter the SirajHub site URL.");
  }
  const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
  if (!(url.protocol === "https:" || url.protocol === "http:" && loopback) || url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
    throw Error("Use the SirajHub HTTPS origin, without a path or credentials. HTTP is allowed on localhost.");
  }
  return url.origin;
}
function cleanFolder(value) {
  const folder = value.trim().replace(/\/+$/, "");
  if (value.trim() && (!folder || folder.split("/").some((part) => !part.trim() || part.startsWith(".") || /[\\:*?"<>|\u0000-\u001f]/.test(part)))) {
    throw Error("Enter a folder inside the vault, such as SirajHub/Books.");
  }
  return folder;
}
function isType(value) {
  return typeof value === "string" && Object.hasOwn(TYPES, value);
}
function isStatus(value) {
  return typeof value === "string" && Object.hasOwn(STATUSES, value);
}
function valueAt(item, field) {
  if (!field.startsWith("metadata.")) return item[field] ?? null;
  let data = item.metadata;
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return null;
    }
  }
  for (const part of field.slice(9).split(".")) {
    if (!data || typeof data !== "object" || !Object.hasOwn(data, part)) return null;
    data = data[part];
  }
  if (data && typeof data === "object" && (!Array.isArray(data) || data.some((value) => value !== null && typeof value === "object"))) {
    return stable(data);
  }
  return data ?? null;
}
function stable(value) {
  if (value instanceof Date) return JSON.stringify(value.toISOString().slice(0, 10));
  if (Array.isArray(value)) return `[${value.map(stable).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, v]) => `${JSON.stringify(key)}:${stable(v)}`).join(",")}}`;
  }
  return JSON.stringify(value ?? null);
}
async function fingerprint(value) {
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(stable(value))));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function validatedValue(field, value) {
  if (field === "title") {
    if (typeof value !== "string" || !value.trim()) throw Error("title must contain text.");
    return value.trim();
  }
  if (field === "status") {
    if (!isStatus(value)) {
      throw Error(`status must be one of: ${statusIds.join(", ")}.`);
    }
    return value;
  }
  if (value == null || value === "") return null;
  if (field === "releaseDate" && value instanceof Date) return value.toISOString().slice(0, 10);
  if (NUMBERS.includes(field)) {
    const min = field === "durationMins" ? 0 : 1;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < min || field === "rating" && value > 7) {
      throw Error(field === "rating" ? "rating must be a whole number from 1 to 7." : `${field} must be a whole number of at least ${min}.`);
    }
    return value;
  }
  if (typeof value !== "string") throw Error(`${field} must contain text.`);
  return value;
}
function initialProperties(item, rules) {
  return Object.fromEntries(rules.map(({ field, property }) => [property, valueAt(item, field)]).filter(([, value]) => value != null));
}
function createPayload(type, props, rules, filename) {
  const values = { contentType: type, title: validatedValue("title", filename) };
  for (const { field, property, writable } of rules) {
    if (writable && Object.hasOwn(props, property) && props[property] != null && props[property] !== "") {
      values[field] = validatedValue(field, props[property]);
    }
  }
  return values;
}
async function planItem(item, local, rules, previous, resolution = "normal", accepted = {}) {
  const writes = {};
  const pulls = {};
  const next = {};
  const problems = [];
  await Promise.all(rules.map(async ({ field, property, writable }) => {
    const key = `${field}=${property}`;
    const remote = valueAt(item, field);
    const current = Object.hasOwn(local, property) ? local[property] : null;
    const [localHash, remoteHash] = await Promise.all([fingerprint(current), fingerprint(remote)]);
    const base = previous[key];
    if (localHash === remoteHash) {
      next[key] = remoteHash;
    } else if (resolution === "pull" || Object.hasOwn(accepted, field) || (base ? localHash === base : !Object.hasOwn(local, property))) {
      pulls[property] = remote;
      next[key] = remoteHash;
    } else if (writable && (resolution === "push" || base && remoteHash === base)) {
      try {
        writes[field] = validatedValue(field, current);
      } catch (error) {
        problems.push(`${property}: ${error.message}`);
      }
    } else {
      problems.push(writable ? `${property}: different values in Obsidian and SirajHub` : `${property}: this property is read-only from SirajHub`);
    }
    if (!Object.hasOwn(next, key) && base) next[key] = base;
  }));
  return { writes, pulls, next, problems: problems.sort() };
}

// src/api.ts
function itemFrom(value) {
  if (!value || typeof value !== "object") throw Error("SirajHub returned an invalid item.");
  const item = value;
  if (typeof item.id !== "string" || !ULID.test(item.id) || typeof item.title !== "string" || !isType(item.contentType) || !Number.isSafeInteger(item.updatedAt) || item.updatedAt < 0) {
    throw Error("SirajHub returned an unsupported item.");
  }
  return item;
}
var SirajApi = class {
  constructor(origin, key) {
    this.origin = origin;
    this.key = key;
  }
  async request(path, method = "GET", data, revision) {
    const headers = {
      Accept: "application/json",
      Authorization: `Bearer ${this.key}`
    };
    if (revision !== void 0) headers["If-Match"] = `"${revision}"`;
    let res;
    try {
      res = await (0, import_obsidian.requestUrl)({
        url: `${this.origin}${path}`,
        method,
        headers,
        throw: false,
        ...data && { contentType: "application/json", body: JSON.stringify(data) }
      });
    } catch {
      throw Error("Could not reach SirajHub. Check the site URL and your network connection.");
    }
    if (res.status === 401 || res.status === 403) throw Error("SirajHub rejected the sync key. Check or replace it in Settings.");
    if (res.status === 404 && path === "/api/sync/account") throw Error("This SirajHub server does not support Obsidian sync yet.");
    if (res.status === 409) throw Error("SirajHub found a potential duplicate. Review the item on the site.");
    if (res.status === 412) throw Error("This item changed in SirajHub during sync. Run sync again.");
    if (res.status >= 400 || res.status < 200) throw Error(`SirajHub returned HTTP ${res.status}.`);
    try {
      return res.json;
    } catch {
      throw Error("The server did not return SirajHub sync data.");
    }
  }
  async account() {
    const result = await this.request("/api/sync/account");
    if (result?.protocolVersion !== 1 || typeof result.accountId !== "string" || !result.accountId) {
      throw Error("This SirajHub server does not support Obsidian sync protocol 1.");
    }
    return `${this.origin}#${result.accountId}`;
  }
  async items() {
    const result = [];
    let after = null;
    do {
      const page = await this.request(`/api/sync/items${after ? `?after=${after}` : ""}`);
      if (!Array.isArray(page?.items) || page.next !== null && (typeof page.next !== "string" || !ULID.test(page.next) || after && page.next <= after)) {
        throw Error("SirajHub returned an invalid sync page.");
      }
      result.push(...page.items.map(itemFrom));
      after = page.next;
    } while (after);
    return result;
  }
  async patch(item, fields) {
    const updated = itemFrom(await this.request(`/api/items/${item.id}`, "PATCH", fields, item.updatedAt));
    if (updated.id !== item.id) throw Error("SirajHub returned the wrong item.");
    return updated;
  }
  async create(fields) {
    return itemFrom(await this.request("/api/items", "POST", fields));
  }
};

// src/main.ts
var typeIds = Object.keys(TYPES);
function baselineProperty(mapping) {
  return mapping.slice(mapping.indexOf("=") + 1);
}
function frontmatterBlock(text) {
  const offset = text.startsWith("\uFEFF") ? 1 : 0;
  const block = (0, import_obsidian2.getFrontMatterInfo)(text.slice(offset));
  return { ...block, contentStart: block.contentStart + offset };
}
function properties(text) {
  const block = frontmatterBlock(text);
  if (!block.exists) {
    if (/^\uFEFF?---[ \t]*\r?\n/.test(text)) throw Error("The frontmatter block is missing its closing delimiter.");
    return {};
  }
  const parsed = (0, import_obsidian2.parseYaml)(block.frontmatter);
  if (parsed == null) return {};
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || parsed instanceof Date) {
    throw Error("Note properties must be a YAML mapping.");
  }
  return parsed;
}
function withProperties(text, props) {
  const block = frontmatterBlock(text);
  const body = text.slice(block.contentStart);
  const bom = text.startsWith("\uFEFF") ? "\uFEFF" : "";
  if (!Object.keys(props).length) return bom + body;
  const newline = text.includes("\r\n") ? "\r\n" : "\n";
  const frontmatter = `---
${(0, import_obsidian2.stringifyYaml)(props).trimEnd()}
---
`.replaceAll("\n", newline);
  return bom + frontmatter + body;
}
function withBody(text, template, item) {
  const { contentStart, exists } = frontmatterBlock(text);
  const newline = text.includes("\r\n") ? "\r\n" : "\n";
  const body = updateBody(text.slice(contentStart), renderBody(template, item), newline);
  const prefix = text.slice(0, contentStart);
  const separator = exists && body && !prefix.endsWith("\n") ? newline : "";
  return prefix + separator + body;
}
function message(error) {
  return error instanceof Error ? error.message : "Unexpected error.";
}
function safeFilename(title) {
  return title.replace(/[\\/:*?"<>|#^[\]\u0000-\u001f]/g, "-").replace(/^[. ]+|[. ]+$/g, "").slice(0, 64).replace(/[. ]+$/g, "") || "SirajHub item";
}
var SirajSync = class extends import_obsidian2.Plugin {
  data;
  saving = Promise.resolve();
  running = false;
  ready = false;
  loaded = false;
  lastAutomatic = Date.now();
  report;
  async onload() {
    const stored = await this.loadData();
    const base = defaults();
    this.data = {
      settings: { ...base, ...stored?.settings, types: { ...base.types } },
      baselines: stored?.baselines ?? {},
      links: stored?.links ?? {},
      managedProperties: stored?.managedProperties ?? {}
    };
    for (const type of typeIds) {
      Object.assign(this.data.settings.types[type], stored?.settings?.types?.[type]);
    }
    this.loaded = true;
    this.registerEvent(this.app.vault.on("rename", (file, oldPath) => this.moveLinks(oldPath, file.path)));
    this.registerEvent(this.app.vault.on("delete", (file) => this.moveLinks(file.path)));
    this.addSettingTab(new SyncSettings(this.app, this));
    this.addCommand({ id: "sync-now", name: "Sync now", callback: () => void this.sync() });
    this.addCommand({ id: "publish-note", name: "Publish current note to SirajHub", callback: () => void this.publish() });
    this.addCommand({ id: "show-report", name: "Show last sync report", callback: () => this.showReport() });
    this.addCommand({ id: "use-hub-values", name: "Resolve current note using SirajHub values", callback: () => void this.resolve("pull") });
    this.addCommand({ id: "use-note-values", name: "Resolve current note using Obsidian values", callback: () => void this.resolve("push") });
    this.app.workspace.onLayoutReady(() => {
      this.ready = this.loaded;
    });
    this.registerInterval(window.setInterval(() => {
      const { interval, secret, server } = this.data.settings;
      if (this.ready && interval > 0 && secret && server && Date.now() - this.lastAutomatic >= interval * 6e4) {
        this.lastAutomatic = Date.now();
        void this.sync(true);
      }
    }, 3e4));
  }
  onunload() {
    this.loaded = false;
  }
  save() {
    const snapshot = structuredClone(this.data);
    const task = this.saving.catch(() => void 0).then(() => this.saveData(snapshot));
    this.saving = task;
    return task;
  }
  moveLinks(oldPath, newPath) {
    let changed = false;
    for (const [path, link] of Object.entries(this.data.links)) {
      if (path !== oldPath && !path.startsWith(`${oldPath}/`)) continue;
      delete this.data.links[path];
      if (newPath !== void 0) this.data.links[newPath + path.slice(oldPath.length)] = link;
      changed = true;
    }
    if (changed) void this.save().catch((error) => new import_obsidian2.Notice(`Siraj Sync: ${message(error)}`, 8e3));
  }
  async updateSettings(next) {
    if (this.running) throw Error("Wait for the current sync to finish before saving settings.");
    if (!next.statuses.length) throw Error("Select at least one status to sync.");
    if (next.server) this.connectionOrigin(next);
    this.data.settings = next;
    this.lastAutomatic = Date.now();
    await this.save();
  }
  connectionOrigin(settings) {
    const origin = serverOrigin(settings.server);
    const current = this.data.settings;
    if (current.server && origin !== current.server && settings.secret && settings.secret === current.secret) {
      throw Error("Select a different Obsidian secret when switching SirajHub servers.");
    }
    return origin;
  }
  api(settings) {
    const origin = this.connectionOrigin(settings);
    if (!settings.secret) throw Error("Use Link\u2026 under Sync key to select your SirajHub key.");
    const key = this.app.secretStorage.getSecret(settings.secret)?.trim();
    if (!key || !KEY.test(key)) throw Error("The linked secret must contain a sync key generated by SirajHub.");
    return new SirajApi(origin, key);
  }
  async checkConnection(settings) {
    await this.api(settings).account();
  }
  async run(operation, quiet = false) {
    if (this.running) {
      if (!quiet) new import_obsidian2.Notice("Siraj Sync: a sync is already running.");
      return;
    }
    this.running = true;
    try {
      await operation(structuredClone(this.data.settings));
    } catch (error) {
      new import_obsidian2.Notice(`Siraj Sync: ${message(error)}`, 8e3);
    } finally {
      this.running = false;
    }
  }
  async linkedNotes(account) {
    const found = /* @__PURE__ */ new Map();
    for (const file of this.app.vault.getMarkdownFiles()) {
      if (!this.loaded) break;
      const link = this.data.links[file.path] ?? this.legacyLink(await this.app.vault.cachedRead(file), file.path);
      if (link?.account !== account) continue;
      const { id } = link;
      const paths = found.get(id) ?? [];
      paths.push(file);
      found.set(id, paths);
    }
    return found;
  }
  legacyLink(raw, path) {
    const frontmatter = frontmatterBlock(raw);
    if (!frontmatter.frontmatter.includes(ID)) {
      if (!frontmatter.exists && /^\uFEFF?---[ \t]*\r?\n/.test(raw) && raw.includes(ID)) {
        throw Error(`${path}: close the frontmatter block before syncing.`);
      }
      return;
    }
    const props = properties(raw);
    const id = props[ID];
    const account = props[ACCOUNT];
    if (typeof account !== "string") return;
    if (typeof id !== "string" || !ULID.test(id)) throw Error(`${path}: the SirajHub item ID is invalid.`);
    return { id, account };
  }
  availablePath(base) {
    let path = `${base}.md`;
    for (let suffix = 2; this.app.vault.getAbstractFileByPath(path) || this.data.links[path]; suffix++) {
      path = `${base} ${suffix}.md`;
    }
    return path;
  }
  async migrateLink(file, link) {
    const raw = await this.app.vault.read(file);
    const legacy = this.legacyLink(raw, file.path);
    const stored = this.data.links[file.path];
    if (!stored && !legacy || [stored, legacy].some((candidate) => candidate && (candidate.id !== link.id || candidate.account !== link.account))) {
      throw Error("This note\u2019s SirajHub link changed.");
    }
    if (legacy) {
      this.data.links[file.path] = link;
      await this.save();
      await this.app.vault.process(file, (current) => {
        if (current !== raw) throw Error("The note changed during sync. Run sync again.");
        const props = properties(current);
        delete props[ID];
        delete props[ACCOUNT];
        return withProperties(current, props);
      });
    }
    const suffix = new RegExp(` \\(${link.id}\\)(?: \\d+)?$`);
    if (suffix.test(file.basename)) {
      const base = file.path.slice(0, -3).replace(suffix, "");
      await this.app.fileManager.renameFile(file, this.availablePath(base));
    }
  }
  async ensureFolder(folder) {
    let path = "";
    for (const segment of folder.split("/")) {
      path = path ? `${path}/${segment}` : segment;
      const entry = this.app.vault.getAbstractFileByPath(path);
      if (entry instanceof import_obsidian2.TFolder) continue;
      if (entry) throw Error(`${path} is a file. Choose a different folder.`);
      await this.app.vault.createFolder(path);
    }
  }
  async importItem(item, account, config) {
    const rules = parseRules(config.properties, item.contentType);
    const props = initialProperties(item, rules);
    const { next } = await planItem(item, props, rules, {});
    await this.ensureFolder(config.folder);
    const path = this.availablePath(`${config.folder}/${safeFilename(item.title)}`);
    const file = await this.app.vault.create(path, withBody(withProperties("", props), config.body, item));
    this.data.links[file.path] = { account, id: item.id };
    const key = `${account}/${item.id}`;
    delete this.data.managedProperties[key];
    this.data.baselines[key] = next;
    await this.save();
  }
  async reconcile(api, file, item, account, config, result, resolution, syncValues, removeUnmappedProperties) {
    const rules = parseRules(config.properties, item.contentType);
    const key = `${account}/${item.id}`;
    const previous = this.data.baselines[key] ?? {};
    const managed = this.data.managedProperties[key] ?? Object.keys(previous).map(baselineProperty);
    const mapped = new Set(rules.map(({ property }) => property));
    const removed = new Set(removeUnmappedProperties ? managed.filter((property) => !mapped.has(property)) : []);
    if (!syncValues && !removed.size) return;
    const raw = await this.app.vault.read(file);
    const local = properties(raw);
    const link = this.data.links[file.path] ?? this.legacyLink(raw, file.path);
    if (link?.id !== item.id || link.account !== account) throw Error("This note\u2019s SirajHub link changed.");
    let plan = syncValues ? await planItem(item, local, rules, previous, resolution) : { writes: {}, pulls: {}, next: { ...previous }, problems: [] };
    let wrote = false;
    if (Object.keys(plan.writes).length && this.loaded) {
      if (await this.app.vault.read(file) !== raw) throw Error("The note changed during sync. Run sync again.");
      const payload = plan.writes;
      item = await api.patch(item, payload);
      result.pushed++;
      wrote = true;
      plan = await planItem(item, local, rules, previous, resolution, payload);
    }
    if (!this.loaded) return;
    const next = { ...local };
    for (const property of removed) delete next[property];
    for (const [property, value] of Object.entries(plan.pulls)) {
      if (value == null) delete next[property];
      else next[property] = value;
    }
    const changedProperties = Object.keys(plan.pulls).length > 0 || [...removed].some((property) => Object.hasOwn(local, property));
    const note = changedProperties ? withProperties(raw, next) : raw;
    const updated = syncValues ? withBody(note, config.body, item) : note;
    if (updated !== raw) {
      await this.app.vault.process(file, (current) => {
        if (current !== raw) throw Error("The note changed during sync. Run sync again.");
        return updated;
      });
      result.pulled++;
    } else if (syncValues && !wrote && !plan.problems.length) {
      result.unchanged++;
    }
    for (const problem of plan.problems) result.issues.push(`${file.path}: ${problem}`);
    const retained = new Set(managed.filter((property) => !removed.has(property)));
    for (const mapping of Object.keys(plan.next)) {
      const property = baselineProperty(mapping);
      if (removed.has(property)) delete plan.next[mapping];
      else retained.add(property);
    }
    this.data.managedProperties[key] = [...retained];
    this.data.baselines[key] = plan.next;
  }
  async sync(automatic = false, only, resolution = "normal") {
    await this.run(async (settings) => {
      this.lastAutomatic = Date.now();
      const api = this.api(settings);
      const account = await api.account();
      const [items, links] = await Promise.all([api.items(), this.linkedNotes(account)]);
      const result = { created: 0, pulled: 0, pushed: 0, unchanged: 0, issues: [] };
      const remoteIds = new Set(items.map(({ id }) => id));
      for (const item of items) {
        if (!this.loaded) break;
        const config = settings.types[item.contentType];
        const notes = links.get(item.id) ?? [];
        if (only && !notes.includes(only)) continue;
        const selected = isStatus(item.status) && settings.statuses.includes(item.status);
        const syncValues = selected && Boolean(config.folder);
        if (!selected) {
          if (only) result.issues.push(`${only.path}: the item's SirajHub status is not selected for sync.`);
        } else if (!config.folder) {
          if (only) result.issues.push(`${only.path}: sync is disabled for ${TYPES[item.contentType]}.`);
        }
        if (!syncValues && (!settings.removeUnmappedProperties || !notes.length)) continue;
        try {
          if (notes.length > 1) throw Error(`More than one note links to this item: ${notes.map((file) => file.path).join(", ")}.`);
          if (notes[0]) {
            if (syncValues) await this.migrateLink(notes[0], { account, id: item.id });
            await this.reconcile(api, notes[0], item, account, config, result, resolution, syncValues, settings.removeUnmappedProperties);
          } else {
            await this.importItem(item, account, config);
            result.created++;
          }
        } catch (error) {
          result.issues.push(`${item.title}: ${message(error)}`);
        }
      }
      for (const [id, files] of links) {
        if (!remoteIds.has(id) && (!only || files.includes(only))) {
          result.issues.push(`${files.map((file) => file.path).join(", ")}: item no longer exists in SirajHub; note kept.`);
        }
      }
      if (only && ![...links.values()].some((files) => files.includes(only))) {
        result.issues.push(`${only.path}: this note isn\u2019t linked to the connected SirajHub account.`);
      }
      this.report = result;
      await this.save();
      if (!automatic || result.issues.length) {
        new import_obsidian2.Notice(`Siraj Sync: ${this.summary(result)}${result.issues.length ? " Run \u201CShow last sync report\u201D for details." : ""}`, 8e3);
      }
    }, automatic);
  }
  summary(result) {
    return `${result.created} imported, ${result.pulled} updated in Obsidian, ${result.pushed} sent to SirajHub, ${result.unchanged} unchanged, ${result.issues.length} to review.`;
  }
  showReport() {
    const report = this.report;
    if (!report) {
      new import_obsidian2.Notice("Siraj Sync: run a sync first.");
      return;
    }
    const modal = new import_obsidian2.Modal(this.app);
    modal.setTitle("Siraj Sync report");
    modal.contentEl.createEl("p", { text: this.summary(report) });
    if (report.issues.length) {
      const list = modal.contentEl.createEl("ul");
      report.issues.forEach((issue) => list.createEl("li", { text: issue }));
    }
    modal.open();
  }
  confirm(title, detail, action, callback) {
    const modal = new import_obsidian2.Modal(this.app);
    modal.setTitle(title);
    modal.contentEl.createEl("p", { text: detail });
    new import_obsidian2.Setting(modal.contentEl).addButton((button) => button.setButtonText("Cancel").onClick(() => modal.close())).addButton((button) => button.setButtonText(action).setCta().onClick(() => {
      modal.close();
      callback();
    }));
    modal.open();
  }
  async resolve(direction) {
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== "md") {
      new import_obsidian2.Notice("Siraj Sync: open a linked Markdown note.");
      return;
    }
    const pull = direction === "pull";
    this.confirm(
      pull ? "Use SirajHub values?" : "Use Obsidian values?",
      pull ? `SirajHub values will replace differing mapped properties in ${file.name}.` : `Editable properties in ${file.name} will take precedence when both copies changed.`,
      pull ? "Use SirajHub values" : "Use Obsidian values",
      () => void this.sync(false, file, direction)
    );
  }
  async publish() {
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== "md") {
      new import_obsidian2.Notice("Siraj Sync: open a Markdown note to publish.");
      return;
    }
    try {
      const settings = structuredClone(this.data.settings);
      const path = file.path;
      const config = typeIds.filter((type2) => {
        const folder = settings.types[type2].folder;
        return folder && path.startsWith(`${folder}/`);
      }).sort((a, b) => settings.types[b].folder.length - settings.types[a].folder.length);
      const type = config[0];
      if (!isType(type)) throw Error("Move this note into a configured SirajHub folder first.");
      if (config[1] && settings.types[type].folder === settings.types[config[1]].folder) {
        throw Error("This folder maps to multiple types. Use a unique folder to publish this note.");
      }
      const raw = await this.app.vault.read(file);
      const local = properties(raw);
      if (this.data.links[path] || Object.hasOwn(local, ID) || Object.hasOwn(local, ACCOUNT)) {
        throw Error("This note already has a SirajHub link.");
      }
      const { properties: mapping, body } = settings.types[type];
      const rules = parseRules(mapping, type);
      const payload = createPayload(type, local, rules, file.basename);
      const fieldNames = Object.keys(payload).filter((field) => field !== "contentType").join(", ");
      this.confirm(
        "Publish note to SirajHub?",
        `Create \u201C${String(payload.title)}\u201D in ${TYPES[type]}. Fields sent: ${fieldNames}.`,
        "Publish",
        () => void this.run(async (current) => {
          if (stable(settings) !== stable(current) || file.path !== path || await this.app.vault.read(file) !== raw) {
            throw Error("The note or settings changed. Review the note and run Publish again.");
          }
          if (this.data.links[file.path]) throw Error("This note already has a SirajHub link.");
          const api = this.api(settings);
          const account = await api.account();
          const item = await api.create(payload);
          const remote = initialProperties(item, rules);
          try {
            if (this.app.vault.getAbstractFileByPath(file.path) !== file) throw Error("The note was removed.");
            this.data.links[file.path] = { account, id: item.id };
            const { next } = await planItem(item, remote, rules, {});
            this.data.baselines[`${account}/${item.id}`] = next;
            await this.save();
          } catch {
            throw Error(`The item was created in SirajHub (ID ${item.id}), but its link could not be saved. Review it on the site before publishing again.`);
          }
          try {
            await this.app.vault.process(file, (content) => {
              const live = properties(content);
              if (Object.hasOwn(live, ID) || Object.hasOwn(live, ACCOUNT)) throw Error("This note is already linked.");
              const merged = { ...live };
              for (const { property, writable } of rules) {
                if (stable(live[property]) !== stable(local[property]) || !writable && Object.hasOwn(live, property)) continue;
                if (Object.hasOwn(remote, property)) merged[property] = remote[property];
                else delete merged[property];
              }
              return withBody(stable(live) === stable(merged) ? content : withProperties(content, merged), body, item);
            });
          } catch {
            throw Error(`The item was created and linked, but the note could not be updated. Run sync again. (${item.id})`);
          }
          new import_obsidian2.Notice("Siraj Sync: note published and linked.");
        })
      );
    } catch (error) {
      new import_obsidian2.Notice(`Siraj Sync: ${message(error)}`, 8e3);
    }
  }
};
var SyncSettings = class extends import_obsidian2.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    const draft = structuredClone(this.plugin.data.settings);
    new import_obsidian2.Setting(containerEl).setName("Connection").setHeading();
    new import_obsidian2.Setting(containerEl).setName("SirajHub URL").setDesc("The site origin, for example https://siraj.example.com.").addText((input) => input.setPlaceholder("https://siraj.example.com").setValue(draft.server).onChange((value) => {
      draft.server = value;
    }));
    new import_obsidian2.Setting(containerEl).setName("Sync key").setDesc("Generate a key under SirajHub \u2192 Settings \u2192 API Keys, then create or select an Obsidian secret.").addComponent((el) => new import_obsidian2.SecretComponent(this.app, el).setValue(draft.secret).onChange((value) => {
      draft.secret = value ?? "";
    }));
    new import_obsidian2.Setting(containerEl).setName("Check connection").setDesc("Tests the URL and sync key above. Use Save settings to apply your changes.").addButton((button) => button.setButtonText("Test connection").onClick(async () => {
      button.setDisabled(true);
      connectionStatus.setText("Connecting to SirajHub\u2026");
      try {
        await this.plugin.checkConnection({ server: draft.server, secret: draft.secret });
        connectionStatus.setText("Connected to SirajHub.");
      } catch (error) {
        connectionStatus.setText(message(error));
      } finally {
        button.setDisabled(false);
      }
    }));
    const connectionStatus = containerEl.createEl("div", { attr: { role: "status" } });
    let minutes = String(draft.interval);
    new import_obsidian2.Setting(containerEl).setName("Sync interval in minutes").setDesc("Enter 0 for manual sync only. Automatic sync runs while Obsidian is open.").addText((input) => input.setValue(minutes).onChange((value) => {
      minutes = value;
    }));
    new import_obsidian2.Setting(containerEl).setName("Statuses to sync").setHeading();
    containerEl.createEl("p", { text: "Select at least one SirajHub status. Items with other statuses are skipped, and their existing notes stay in your vault." });
    const selectedStatuses = new Set(draft.statuses);
    for (const status2 of statusIds) {
      new import_obsidian2.Setting(containerEl).setName(STATUSES[status2]).addToggle((toggle) => toggle.setValue(selectedStatuses.has(status2)).onChange((enabled) => {
        if (enabled) selectedStatuses.add(status2);
        else selectedStatuses.delete(status2);
      }));
    }
    new import_obsidian2.Setting(containerEl).setName("Library folders and note content").setHeading();
    new import_obsidian2.Setting(containerEl).setName("Remove properties when mappings are removed").setDesc("Delete previously synced properties from linked notes when their mappings are removed, even if the item is excluded from regular sync.").addToggle((toggle) => toggle.setValue(draft.removeUnmappedProperties).onChange((enabled) => {
      draft.removeUnmappedProperties = enabled;
    }));
    containerEl.createEl("p", { text: "Clear a folder to skip that type. Use one field = property mapping per line. Fields starting with metadata. are imported from SirajHub. Changes to folders affect new imports; linked notes stay where you put them." });
    for (const type of typeIds) {
      const details = containerEl.createEl("details");
      details.createEl("summary", { text: TYPES[type] });
      const config = draft.types[type];
      new import_obsidian2.Setting(details).setName("Folder").addText((input) => input.setValue(config.folder).onChange((value) => {
        config.folder = value;
      }));
      new import_obsidian2.Setting(details).setName("Property mappings").addTextArea((input) => {
        input.inputEl.rows = 9;
        input.inputEl.cols = 32;
        input.setValue(config.properties).onChange((value) => {
          config.properties = value;
        });
      });
      new import_obsidian2.Setting(details).setName("Note body template").setDesc("Optional Markdown. Use {{creator}}, {{description}}, or {{metadata.genres}} to insert SirajHub values.").addTextArea((input) => {
        input.inputEl.rows = 6;
        input.inputEl.cols = 32;
        input.setValue(config.body).onChange((value) => {
          config.body = value;
        });
      });
    }
    const status = containerEl.createEl("p", { attr: { role: "status" } });
    new import_obsidian2.Setting(containerEl).addButton((button) => button.setButtonText("Save settings").setCta().onClick(async () => {
      status.setText("");
      try {
        const interval = Number(minutes);
        if (!/^\d+$/.test(minutes.trim()) || !Number.isInteger(interval) || interval > 1440) {
          throw Error("Enter a whole number from 0 to 1440 minutes.");
        }
        const next = structuredClone(draft);
        next.interval = interval;
        next.statuses = statusIds.filter((status2) => selectedStatuses.has(status2));
        next.server = draft.server.trim() ? serverOrigin(draft.server) : "";
        for (const type of typeIds) {
          try {
            next.types[type].folder = cleanFolder(next.types[type].folder);
            parseRules(next.types[type].properties, type);
            validateBodyTemplate(next.types[type].body, type);
          } catch (error) {
            throw Error(`${TYPES[type]}: ${message(error)}`);
          }
        }
        await this.plugin.updateSettings(next);
        status.setText("Settings saved.");
      } catch (error) {
        status.setText(message(error));
      }
    }));
  }
};
